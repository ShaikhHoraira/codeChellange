"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ManageDevice = void 0;
class ManageDevice {
    constructor(payLooad) {
        this.payload = payLooad;
    }
    async saveData() {
        console.info(this.payload);
    }
}
exports.ManageDevice = ManageDevice;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2F2ZURhdGEuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzYXZlRGF0YS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxNQUFhLFlBQVk7SUFHekIsWUFBWSxRQUFnQjtRQUN4QixJQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQztJQUM1QixDQUFDO0lBRU0sS0FBSyxDQUFDLFFBQVE7UUFDakIsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7SUFDOUIsQ0FBQztDQUVBO0FBWEQsb0NBV0MiLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCBjbGFzcyBNYW5hZ2VEZXZpY2Uge1xucHVibGljIHBheWxvYWQgOiBvYmplY3Q7XG5cbmNvbnN0cnVjdG9yKHBheUxvb2FkOiBvYmplY3Qpe1xuICAgIHRoaXMucGF5bG9hZCA9IHBheUxvb2FkO1xufVxuXG5wdWJsaWMgYXN5bmMgc2F2ZURhdGEoKXtcbiAgICBjb25zb2xlLmluZm8odGhpcy5wYXlsb2FkKVxufVxuXG59XG4iXX0=
export declare const handler: (event: any, _context: any) => Promise<{
    statusCode: number;
    body: string;
}>;

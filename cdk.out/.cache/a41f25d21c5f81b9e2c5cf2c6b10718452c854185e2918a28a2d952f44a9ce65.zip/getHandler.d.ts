import { Handler } from "aws-cdk-lib/aws-lambda";
export declare const handler: Handler;

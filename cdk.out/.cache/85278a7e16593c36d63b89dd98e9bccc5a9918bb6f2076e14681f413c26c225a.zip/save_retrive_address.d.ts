import { Handler } from "aws-cdk-lib/aws-lambda";
export declare const TuHandler: Handler;

import { Handler } from "aws-cdk-lib/aws-lambda";
export declare const handler: Handler;
export declare function saveDevice(event: object): Promise<boolean>;

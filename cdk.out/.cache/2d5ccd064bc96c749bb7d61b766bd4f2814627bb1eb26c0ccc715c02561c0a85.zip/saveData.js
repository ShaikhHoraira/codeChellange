"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ManageDevice = void 0;
class ManageDevice {
    constructor(payLooad) {
        this.payload = payLooad;
    }
    async saveData() {
        console.info(this.payload);
        return this.payload;
    }
}
exports.ManageDevice = ManageDevice;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2F2ZURhdGEuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzYXZlRGF0YS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxNQUFhLFlBQVk7SUFHekIsWUFBWSxRQUFnQjtRQUN4QixJQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQztJQUM1QixDQUFDO0lBRU0sS0FBSyxDQUFDLFFBQVE7UUFDakIsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7UUFDMUIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFBO0lBRXZCLENBQUM7Q0FFQTtBQWJELG9DQWFDIiwic291cmNlc0NvbnRlbnQiOlsiXG5leHBvcnQgY2xhc3MgTWFuYWdlRGV2aWNlIHtcbnB1YmxpYyBwYXlsb2FkIDogb2JqZWN0O1xuXG5jb25zdHJ1Y3RvcihwYXlMb29hZDogb2JqZWN0KXtcbiAgICB0aGlzLnBheWxvYWQgPSBwYXlMb29hZDtcbn1cblxucHVibGljIGFzeW5jIHNhdmVEYXRhKCl7XG4gICAgY29uc29sZS5pbmZvKHRoaXMucGF5bG9hZClcbiAgICByZXR1cm4gdGhpcy5wYXlsb2FkXG4gICAgXG59XG5cbn1cbiJdfQ==
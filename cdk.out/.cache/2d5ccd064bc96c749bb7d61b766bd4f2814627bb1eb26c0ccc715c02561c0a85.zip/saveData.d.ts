export declare class ManageDevice {
    payload: object;
    constructor(payLooad: object);
    saveData(): Promise<object>;
}
